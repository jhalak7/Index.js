function changeImageSize()
{
	document.querySelector("#resOne").style.width="100px";
	document.querySelector("#resOne").style.height="100px";
	document.querySelector("#resTwo").style.width="100px";
	document.querySelector("#resTwo").style.height="100px";
	document.querySelector("#resThree").style.width="100px";
	document.querySelector("#resThree").style.height="100px";
	document.querySelector("#resFour").style.width="100px";
	document.querySelector("#resFour").style.height="100px";
	document.querySelector("#resFive").style.width="100px";
	document.querySelector("#resFive").style.height="100px";
	document.querySelector("#resSix").style.width="100px";
	document.querySelector("#resSix").style.height="100px";
	document.querySelector("#resSeven").style.width="100px";
	document.querySelector("#resSeven").style.height="100px";
	document.querySelector("#resEight").style.width="100px";
	document.querySelector("#resEight").style.height="100px";

	document.getElementById("resOne").addEventListener("mouseover",function(){
		document.getElementById("resOne").style.width="250px";
		document.getElementById("resOne").style.height="250px";
	})

	document.getElementById("resOne").addEventListener("mouseout",function(){
		document.getElementById("resOne").style.width="100px";
		document.getElementById("resOne").style.height="100px";
	})

	document.getElementById("resOne").addEventListener("click",function(){
		window.open("https://www.amazon.in/Domenico-Electronic-Multi-Function-Beginners-Chargeable/dp/B0832WZB9K/ref=sr_1_5?dchild=1&keywords=piano&qid=1606323664&sr=8-5");
	})
	

	document.getElementById("resTwo").addEventListener("mouseover",function(){
		document.getElementById("resTwo").style.width="250px";
		document.getElementById("resTwo").style.height="250px";
	})

	document.getElementById("resTwo").addEventListener("mouseout",function(){
		document.getElementById("resTwo").style.width="100px";
		document.getElementById("resTwo").style.height="100px";
	})

	document.getElementById("resTwo").addEventListener("click",function(){
		window.open("https://www.amazon.in/Vilon-Pitcher-Plastic-Drinking-Beverage/dp/B08CXJNLGS/ref=sr_1_1_sspa?dchild=1&keywords=jug&qid=1606323925&sr=8-1-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyWUlTSDBZV1gzTUkxJmVuY3J5cHRlZElkPUEwNjM4ODQ4MUYyT0pHMVNDOEJVViZlbmNyeXB0ZWRBZElkPUEwNTU1NzkwMkUzSjBPN0tKMEEyWiZ3aWRnZXROYW1lPXNwX2F0ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU=");
	})

	document.getElementById("resThree").addEventListener("mouseover",function(){
		document.getElementById("resThree").style.width="250px";
		document.getElementById("resThree").style.height="250px";
	})

	document.getElementById("resThree").addEventListener("mouseout",function(){
		document.getElementById("resThree").style.width="100px";
		document.getElementById("resThree").style.height="100px";
	})

	document.getElementById("resThree").addEventListener("click",function(){
		window.open("https://www.amazon.in/Labzio-Premium-Human-Removable-Calvarium/dp/B073VQ14HL/ref=sr_1_1?dchild=1&keywords=skull&qid=1606323970&sr=8-1");
	})

	document.getElementById("resFour").addEventListener("mouseover",function(){
		document.getElementById("resFour").style.width="250px";
		document.getElementById("resFour").style.height="250px";
	})

	document.getElementById("resFour").addEventListener("mouseout",function(){
		document.getElementById("resFour").style.width="100px";
		document.getElementById("resFour").style.height="100px";
	})

	document.getElementById("resFour").addEventListener("click",function(){
		window.open("https://www.amazon.in/TOYXE-Hanging-Birthday-Anniversary-Decoration/dp/B07F32M12F/ref=sr_1_5?dchild=1&keywords=rainbow&qid=1606323995&sr=8-5");
	})

	document.getElementById("resFive").addEventListener("mouseover",function(){
		document.getElementById("resFive").style.width="250px";
		document.getElementById("resFive").style.height="250px";
	})

	document.getElementById("resFive").addEventListener("mouseout",function(){
		document.getElementById("resFive").style.width="100px";
		document.getElementById("resFive").style.height="100px";
	})

	document.getElementById("resFive").addEventListener("click",function(){
		window.open("https://www.amazon.in/Domenico-Electronic-Multi-Function-Beginners-Chargeable/dp/B0832WZB9K/ref=sr_1_5?dchild=1&keywords=piano&qid=1606323664&sr=8-5");
	})

	document.getElementById("resSix").addEventListener("mouseover",function(){
		document.getElementById("resSix").style.width="250px";
		document.getElementById("resSix").style.height="250px";
	})

	document.getElementById("resSix").addEventListener("mouseout",function(){
		document.getElementById("resSix").style.width="100px";
		document.getElementById("resSix").style.height="100px";
	})

	document.getElementById("resSix").addEventListener("click",function(){
		window.open("https://www.amazon.in/Toyshine-Dixon-Super-Table-Tennis/dp/B08L6M86DX/ref=sr_1_4_sspa?crid=35IWJ2JOQ7JF3&dchild=1&keywords=table+tennis&qid=1606324032&sprefix=table+tenn%2Caps%2C329&sr=8-4-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyQ0E5MjRHMUFUUDQyJmVuY3J5cHRlZElkPUEwNjMxODgxMlVJS0kwWFpXVE5HMiZlbmNyeXB0ZWRBZElkPUEwNjEzNDY5MjhEUkFYVFpEV1lOOCZ3aWRnZXROYW1lPXNwX2F0ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU=");
	})

	document.getElementById("resSeven").addEventListener("mouseover",function(){
		document.getElementById("resSeven").style.width="250px";
		document.getElementById("resSeven").style.height="250px";
	})

	document.getElementById("resSeven").addEventListener("mouseout",function(){
		document.getElementById("resSeven").style.width="100px";
		document.getElementById("resSeven").style.height="100px";
	})

	document.getElementById("resSeven").addEventListener("click",function(){
		window.open("https://www.amazon.in/LimeStone-Functioning-Silver-Color-Quartz/dp/B08G4Q2LZM/ref=sr_1_4_sspa?dchild=1&keywords=watch&qid=1606324061&smid=A21QMAD55OZHHJ&sr=8-4-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUFCSk9TMUxSMlpMRkomZW5jcnlwdGVkSWQ9QTA2MDAxMTVLREtKOU45WjA1MDYmZW5jcnlwdGVkQWRJZD1BMDAwODAwODJYSlZNQkFKS01XNlAmd2lkZ2V0TmFtZT1zcF9hdGYmYWN0aW9uPWNsaWNrUmVkaXJlY3QmZG9Ob3RMb2dDbGljaz10cnVl");
	})

	document.getElementById("resEight").addEventListener("mouseover",function(){
		document.getElementById("resEight").style.width="250px";
		document.getElementById("resEight").style.height="250px";
	})

	document.getElementById("resEight").addEventListener("mouseout",function(){
		document.getElementById("resEight").style.width="100px";
		document.getElementById("resEight").style.height="100px";
	})

	document.getElementById("resEight").addEventListener("click",function(){
		window.open("https://www.amazon.in/TIMBER-CHEESE-Ergonomic-Warranty-Promoting/dp/B08N6W3TZW/ref=sr_1_2_sspa?dchild=1&keywords=chair&qid=1606324081&sr=8-2-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyUU00SzU0Q09XNDFXJmVuY3J5cHRlZElkPUEwMDA4MjAxMzM1NzRBU0ZVNUc5SyZlbmNyeXB0ZWRBZElkPUEwMDIwMzE3M0dVTVVEMldLWkFNQiZ3aWRnZXROYW1lPXNwX2F0ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU=");
	})

}
