function styleIn(){
	document.getElementById("tableStyle").classList.add("addStyle");
}
function styleOut(){

	document.getElementById("tableStyle").classList.remove("addStyle");
}