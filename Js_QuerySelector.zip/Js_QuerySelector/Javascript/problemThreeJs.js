function changeColor(){
	document.querySelector("#firstTag").style.backgroundColor="yellow";
	document.querySelector("#firstPara").style.backgroundColor="orange";
	document.querySelector("#secondTag").style.backgroundColor="yellow";
	document.querySelector("#secondPara").style.backgroundColor="orange";
}
function everythingWhite(){

	document.querySelector("#firstTag").style.backgroundColor="white";
	document.querySelector("#firstPara").style.backgroundColor="white";
	document.querySelector("#secondTag").style.backgroundColor="white";
	document.querySelector("#secondPara").style.backgroundColor="white";
}