function cookieAsk(){
	var colorCookie=prompt("Enter color you want to display in hex code");
	var cookieName=prompt("Enter your name");
	var cookieDemo=document.cookie="TestCookie: username="+cookieName+" color= "+colorCookie;
	if(confirm("A cookie will be set.Delete cookie?"))
	{
		alert("Here is the cookie which will be deleted "+cookieDemo);

    	document.cookie=cookieDemo+";max-age=0";
    	cookieDemo=document.cookie;
    	alert("Cookie deleted "+cookieDemo);  
	}
	else
	{
		alert("Here is the cookie which is set on your system"+",cookie: color="+colorCookie+" ,username= "+cookieName);
		
		document.bgColor=colorCookie;
		document.getElementById("show").innerHTML="Your background color is: "+colorCookie;
		document.getElementById("showTwo").innerHTML="Your name is: "+cookieName;
		document.getElementById("showThree").innerHTML="Cookie contents: "+cookieDemo;
	}
}
 
  