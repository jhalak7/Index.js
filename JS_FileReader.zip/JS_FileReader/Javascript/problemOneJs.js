function saveLocal(){
	var nameJs=prompt("Enter your name");
	localStorage.setItem("name",nameJs);
}