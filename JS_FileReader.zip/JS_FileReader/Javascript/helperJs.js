function helperFunction(){
	document.getElementById("nameId").innerHTML="Hello "+localStorage.getItem("name");
}